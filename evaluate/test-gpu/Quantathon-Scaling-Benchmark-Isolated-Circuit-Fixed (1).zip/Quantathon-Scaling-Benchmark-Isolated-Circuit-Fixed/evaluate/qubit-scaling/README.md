# Isolated qubit and generator scaling benchmark

This folder is intentionally separate from the FastAPI/frontend demo path.
The existing frontend, `sample-run-request.json`, default dataset, and API behavior
remain unchanged.

## Input CSV

`benchmark_plan.csv` controls each experiment row.

Important columns:

- `experiment_mode=qubit_only`: keep the original 10-generator dataset and only change the active block/qubit count.
- `experiment_mode=joint_scale`: generate a larger synthetic dataset, scale demand/renewable/reserve by the actual total-Pmax ratio, then run the requested active block.
- `total_generators`: number of generators in the generated dataset.
- `qubit_budget`: maximum active variables.
- `candidate_generators × candidate_hours`: actual structured block size. This product must not exceed the budget.
- `shots`, `optimizer_evaluations`, `top_k`, `max_quantum_rounds`: time-quality controls.
- `repetitions`: independent runs with shifted seeds.

The CSV is an experiment plan, not a backend mapping. It never overrides frontend requests.

## Output files

The runner writes after every case:

- `results/scaling_raw.csv`: one row per repetition.
- `results/scaling_summary.csv`: aggregate by case.
- `results/scaling_raw.json` and `results/scaling_summary.json`.
- `results/datasets/*.json`: exact generated dataset used by each run.

## Colab commands

Run the safer range first:

```bash
CUDAQ_TARGET=nvidia REQUIRE_CUDAQ=1 PYTHONPATH=backend \
python evaluate/qubit-scaling/run_scaling.py \
  --target nvidia --require-cudaq --max-qubits 24
```

Then test large cases one at a time:

```bash
CUDAQ_TARGET=nvidia REQUIRE_CUDAQ=1 PYTHONPATH=backend \
python evaluate/qubit-scaling/run_scaling.py \
  --target nvidia --require-cudaq --case q28_joint

CUDAQ_TARGET=nvidia REQUIRE_CUDAQ=1 PYTHONPATH=backend \
python evaluate/qubit-scaling/run_scaling.py \
  --target nvidia --require-cudaq --case q30_joint
```

A T4 may fail or become impractically slow at the largest statevector sizes. The runner records the error in CSV and preserves all earlier successful rows.

## Fair interpretation

`qubit_only` isolates the effect of the quantum neighborhood size.

`joint_scale` changes both system size and qubit count, so it measures end-to-end scalability rather than a pure qubit effect. Keep these modes in separate plots and conclusions.
