from __future__ import annotations

import argparse
import csv
import json
import math
import os
import statistics
import sys
import time
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
BACKEND_ROOT = ROOT / "backend"
if str(BACKEND_ROOT) not in sys.path:
    sys.path.insert(0, str(BACKEND_ROOT))

from app.datasets.default_dataset import load_default_dataset
from app.datasets.scaling import dataset_scaling_metadata, generate_scaled_dataset
from app.models.schemas import ClassicalConfig, HybridConfig, RunConfig
from app.services.pipeline import PipelineService


@dataclass(frozen=True)
class PlanRow:
    case_id: str
    enabled: bool
    experiment_mode: str
    total_generators: int
    qubit_budget: int
    candidate_generators: int
    candidate_hours: int
    qaoa_depth: int
    shots: int
    optimizer_shots: int
    optimizer_evaluations: int
    top_k: int
    max_quantum_rounds: int
    repetitions: int
    seed: int
    classical_time_limit_seconds: float
    classical_mip_gap: float

    @property
    def active_qubits_requested(self) -> int:
        return self.candidate_generators * self.candidate_hours


def _as_bool(value: str) -> bool:
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}


def load_plan(path: Path) -> list[PlanRow]:
    rows: list[PlanRow] = []
    with path.open("r", newline="", encoding="utf-8") as handle:
        for raw in csv.DictReader(handle):
            row = PlanRow(
                case_id=raw["case_id"].strip(),
                enabled=_as_bool(raw.get("enabled", "1")),
                experiment_mode=raw.get("experiment_mode", "joint_scale").strip(),
                total_generators=int(raw["total_generators"]),
                qubit_budget=int(raw["qubit_budget"]),
                candidate_generators=int(raw["candidate_generators"]),
                candidate_hours=int(raw["candidate_hours"]),
                qaoa_depth=int(raw["qaoa_depth"]),
                shots=int(raw["shots"]),
                optimizer_shots=int(raw["optimizer_shots"]),
                optimizer_evaluations=int(raw["optimizer_evaluations"]),
                top_k=int(raw["top_k"]),
                max_quantum_rounds=int(raw["max_quantum_rounds"]),
                repetitions=int(raw["repetitions"]),
                seed=int(raw["seed"]),
                classical_time_limit_seconds=float(raw["classical_time_limit_seconds"]),
                classical_mip_gap=float(raw["classical_mip_gap"]),
            )
            validate_plan_row(row)
            rows.append(row)
    return rows


def validate_plan_row(row: PlanRow) -> None:
    if not row.case_id:
        raise ValueError("case_id cannot be empty.")
    if row.experiment_mode not in {"joint_scale", "qubit_only"}:
        raise ValueError(
            f"{row.case_id}: experiment_mode must be joint_scale or qubit_only."
        )
    if row.total_generators < row.candidate_generators:
        raise ValueError(
            f"{row.case_id}: candidate_generators exceeds total_generators."
        )
    if row.active_qubits_requested > row.qubit_budget:
        raise ValueError(
            f"{row.case_id}: block shape uses {row.active_qubits_requested} qubits, "
            f"exceeding budget {row.qubit_budget}."
        )
    if row.qubit_budget > 30:
        raise ValueError(
            f"{row.case_id}: this T4-oriented benchmark intentionally caps the plan at 30 qubits."
        )
    if row.repetitions < 1:
        raise ValueError(f"{row.case_id}: repetitions must be positive.")


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _safe_mean(values: list[float]) -> float | None:
    finite = [value for value in values if math.isfinite(value)]
    return round(statistics.fmean(finite), 6) if finite else None


def _safe_stdev(values: list[float]) -> float | None:
    finite = [value for value in values if math.isfinite(value)]
    return round(statistics.stdev(finite), 6) if len(finite) >= 2 else None


def summarize(raw_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in raw_rows:
        grouped[str(row["case_id"])].append(row)

    summaries: list[dict[str, Any]] = []
    for case_id, rows in grouped.items():
        successes = [row for row in rows if row.get("status") == "completed"]
        first = rows[0]
        summary = {
            "case_id": case_id,
            "experiment_mode": first.get("experiment_mode"),
            "total_generators": first.get("total_generators"),
            "qubit_budget": first.get("qubit_budget"),
            "active_qubits_requested": first.get("active_qubits_requested"),
            "candidate_generators": first.get("candidate_generators"),
            "candidate_hours": first.get("candidate_hours"),
            "attempted_runs": len(rows),
            "successful_runs": len(successes),
            "success_rate": round(len(successes) / max(len(rows), 1), 6),
            "hybrid_sources": "|".join(sorted({str(row.get("hybrid_source")) for row in successes})),
            "objective_modes": "|".join(sorted({str(row.get("objective_mode")) for row in successes})),
            "classical_feasibility_rate": _safe_mean([
                1.0 if row.get("classical_feasible") else 0.0 for row in successes
            ]),
            "hybrid_feasibility_rate": _safe_mean([
                1.0 if row.get("hybrid_feasible") else 0.0 for row in successes
            ]),
            "classical_cost_avg": _safe_mean([float(row["classical_cost"]) for row in successes]),
            "hybrid_cost_avg": _safe_mean([float(row["hybrid_cost"]) for row in successes]),
            "cost_gap_percent_avg": _safe_mean([float(row["cost_gap_percent"]) for row in successes]),
            "classical_runtime_ms_avg": _safe_mean([float(row["classical_runtime_ms"]) for row in successes]),
            "hybrid_runtime_ms_avg": _safe_mean([float(row["hybrid_runtime_ms"]) for row in successes]),
            "hybrid_runtime_ms_stdev": _safe_stdev([float(row["hybrid_runtime_ms"]) for row in successes]),
            "quantum_backend_runtime_ms_avg": _safe_mean([
                float(row["quantum_backend_runtime_ms"]) for row in successes
            ]),
            "total_runtime_ms_avg": _safe_mean([float(row["total_runtime_ms"]) for row in successes]),
            "errors": " | ".join(str(row.get("error")) for row in rows if row.get("error")),
        }
        summaries.append(summary)
    return sorted(summaries, key=lambda row: int(row["qubit_budget"]))


def build_dataset(row: PlanRow, repetition_seed: int):
    base = load_default_dataset()
    if row.experiment_mode == "qubit_only":
        return base.model_copy(deep=True), dataset_scaling_metadata(base, base)
    dataset = generate_scaled_dataset(
        base,
        row.total_generators,
        seed=repetition_seed,
        dataset_id=f"bench_{row.case_id}_seed{repetition_seed}",
    )
    return dataset, dataset_scaling_metadata(base, dataset)


def run_one(
    row: PlanRow,
    repetition: int,
    *,
    target: str,
    require_cudaq: bool,
    output_dir: Path,
) -> dict[str, Any]:
    repetition_seed = row.seed + repetition
    dataset, dataset_meta = build_dataset(row, repetition_seed)

    dataset_dir = output_dir / "datasets"
    dataset_dir.mkdir(parents=True, exist_ok=True)
    dataset_path = dataset_dir / f"{row.case_id}_rep{repetition}_seed{repetition_seed}.json"
    dataset_path.write_text(dataset.model_dump_json(indent=2), encoding="utf-8")

    config = RunConfig(
        dataset_id=dataset.id,
        classical_config=ClassicalConfig(
            mip_gap=row.classical_mip_gap,
            time_limit_seconds=row.classical_time_limit_seconds,
        ),
        hybrid_config=HybridConfig(
            qubit_budget=row.qubit_budget,
            candidate_generators=row.candidate_generators,
            candidate_hours=row.candidate_hours,
            qaoa_depth=row.qaoa_depth,
            shots=row.shots,
            optimizer_shots=row.optimizer_shots,
            optimizer_evaluations=row.optimizer_evaluations,
            top_k=row.top_k,
            max_quantum_rounds=row.max_quantum_rounds,
            random_seed=repetition_seed,
            quantum_target=target,
            allow_numpy_fallback=not require_cudaq,
        ),
    )

    service = PipelineService()
    service.datasets.register_dataset(dataset)
    started = time.perf_counter()
    summary = service.execute_run(config)
    wall_runtime_ms = (time.perf_counter() - started) * 1000.0
    result = summary.result or {}
    classical = result.get("classical", {})
    hybrid = result.get("hybrid", {})
    comparison = result.get("comparison", {})
    rounds = hybrid.get("quantum_rounds", []) or []
    last_backend = rounds[-1].get("backend", {}) if rounds else {}
    raw_payload = last_backend.get("raw_payload", {}) or {}
    quantum_backend_runtime = sum(
        float(round_row.get("backend", {}).get("backend_runtime_ms", 0.0))
        for round_row in rounds
    )

    return {
        "case_id": row.case_id,
        "repetition": repetition,
        "seed": repetition_seed,
        "status": "completed",
        "experiment_mode": row.experiment_mode,
        **dataset_meta,
        "dataset_json": str(dataset_path.relative_to(output_dir)),
        "qubit_budget": row.qubit_budget,
        "active_qubits_requested": row.active_qubits_requested,
        "active_qubits_actual": hybrid.get("active_qubits"),
        "candidate_generators": row.candidate_generators,
        "candidate_hours": row.candidate_hours,
        "qaoa_depth": row.qaoa_depth,
        "shots": row.shots,
        "optimizer_shots": row.optimizer_shots,
        "optimizer_evaluations": row.optimizer_evaluations,
        "top_k": row.top_k,
        "max_quantum_rounds": row.max_quantum_rounds,
        "round_count": hybrid.get("round_count"),
        "target": raw_payload.get("target", target),
        "hybrid_source": hybrid.get("backend_source"),
        "objective_mode": raw_payload.get("objective_mode"),
        "optimizer_success": raw_payload.get("success"),
        "fallback_reason": raw_payload.get("fallback_reason"),
        "classical_feasible": classical.get("feasible"),
        "hybrid_feasible": hybrid.get("feasible"),
        "classical_cost": comparison.get("classical_cost"),
        "hybrid_cost": comparison.get("hybrid_cost"),
        "cost_gap_percent": comparison.get("cost_gap_percent"),
        "classical_runtime_ms": comparison.get("classical_runtime_ms"),
        "hybrid_runtime_ms": comparison.get("hybrid_runtime_ms"),
        "quantum_backend_runtime_ms": round(quantum_backend_runtime, 6),
        "total_runtime_ms": summary.metrics.get("total_runtime_ms"),
        "wall_runtime_ms": round(wall_runtime_ms, 6),
        "hybrid_residual_l2_mw": hybrid.get("residual_l2_mw"),
        "hybrid_curtailment_mwh": hybrid.get("total_renewable_curtailment_mwh"),
        "error": None,
    }


def failure_row(row: PlanRow, repetition: int, exc: Exception) -> dict[str, Any]:
    return {
        "case_id": row.case_id,
        "repetition": repetition,
        "seed": row.seed + repetition,
        "status": "failed",
        "experiment_mode": row.experiment_mode,
        "total_generators": row.total_generators,
        "qubit_budget": row.qubit_budget,
        "active_qubits_requested": row.active_qubits_requested,
        "candidate_generators": row.candidate_generators,
        "candidate_hours": row.candidate_hours,
        "hybrid_source": None,
        "error": f"{type(exc).__name__}: {exc}",
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Run isolated generator/qubit scaling experiments without changing "
            "the FastAPI/frontend demo configuration."
        )
    )
    parser.add_argument(
        "--plan",
        type=Path,
        default=Path(__file__).with_name("benchmark_plan.csv"),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(__file__).with_name("results"),
    )
    parser.add_argument("--target", default=os.getenv("CUDAQ_TARGET", "nvidia"))
    parser.add_argument("--require-cudaq", action="store_true")
    parser.add_argument("--max-qubits", type=int, default=None)
    parser.add_argument("--case", action="append", default=[])
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    os.environ["CUDAQ_TARGET"] = args.target
    if args.require_cudaq:
        os.environ["REQUIRE_CUDAQ"] = "1"

    plan = [row for row in load_plan(args.plan) if row.enabled]
    if args.max_qubits is not None:
        plan = [row for row in plan if row.qubit_budget <= args.max_qubits]
    if args.case:
        requested = set(args.case)
        plan = [row for row in plan if row.case_id in requested]

    if not plan:
        raise SystemExit("No benchmark cases selected.")

    print("Isolated qubit/system scaling benchmark")
    print(f"project_root={ROOT}")
    print(f"plan={args.plan}")
    print(f"output_dir={args.output_dir}")
    print(f"target={args.target}")
    print(f"require_cudaq={args.require_cudaq}")
    print(f"cases={[row.case_id for row in plan]}")

    raw_rows: list[dict[str, Any]] = []
    raw_csv = args.output_dir / "scaling_raw.csv"
    raw_json = args.output_dir / "scaling_raw.json"
    summary_csv = args.output_dir / "scaling_summary.csv"
    summary_json = args.output_dir / "scaling_summary.json"

    failures = 0
    for row in plan:
        for repetition in range(row.repetitions):
            print(
                f"\n[{row.case_id}] rep={repetition} generators={row.total_generators} "
                f"budget={row.qubit_budget} block={row.candidate_generators}x{row.candidate_hours}"
            )
            try:
                result = run_one(
                    row,
                    repetition,
                    target=args.target,
                    require_cudaq=args.require_cudaq,
                    output_dir=args.output_dir,
                )
                print(
                    f"  source={result['hybrid_source']} active={result['active_qubits_actual']} "
                    f"hybrid_ms={result['hybrid_runtime_ms']} gap={result['cost_gap_percent']}%"
                )
            except Exception as exc:
                failures += 1
                result = failure_row(row, repetition, exc)
                print(f"  ERROR: {result['error']}")

            raw_rows.append(result)
            # Persist after every case so Colab disconnects do not lose prior results.
            _write_csv(raw_csv, raw_rows)
            raw_json.write_text(json.dumps(raw_rows, indent=2, ensure_ascii=False), encoding="utf-8")
            summary_rows = summarize(raw_rows)
            _write_csv(summary_csv, summary_rows)
            summary_json.write_text(
                json.dumps(summary_rows, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )

    print("\nOutputs:")
    print(f"  {raw_csv}")
    print(f"  {summary_csv}")
    print(f"  {raw_json}")
    print(f"  {summary_json}")
    print(f"failures={failures}")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
