from __future__ import annotations

from collections import defaultdict

from app.models.schemas import CandidateBlock, CandidateScore, DatasetModel


def select_candidate_block(
    dataset: DatasetModel,
    scores: list[CandidateScore],
    candidate_generators: int = 2,
    candidate_hours: int = 5,
    qubit_budget: int = 10,
) -> CandidateBlock:
    """Select a structured generator × consecutive-hour active block.

    The demo defaults remain 2 generators × 5 hours = 10 qubits. Benchmark
    callers may request larger shapes without changing the frontend contract.
    """
    if qubit_budget <= 0:
        raise ValueError("qubit_budget must be positive.")
    if candidate_generators <= 0 or candidate_hours <= 0:
        raise ValueError("candidate_generators and candidate_hours must be positive.")
    if not dataset.generators or not dataset.hours:
        raise ValueError("Dataset must contain generators and hours.")

    generator_count = min(candidate_generators, len(dataset.generators), qubit_budget)
    max_hours_from_budget = qubit_budget // generator_count
    if max_hours_from_budget <= 0:
        raise ValueError("Qubit budget is too small for the requested generator count.")
    hour_count = min(candidate_hours, len(dataset.hours), max_hours_from_budget)

    score_map = {(s.generator_id, s.hour): float(s.final_score) for s in scores}
    generator_ids = [gen.id for gen in dataset.generators]

    best: tuple[list[int], list[str], float] | None = None
    for start in range(0, len(dataset.hours) - hour_count + 1):
        window = list(dataset.hours[start:start + hour_count])
        per_gen: dict[str, float] = defaultdict(float)
        for gid in generator_ids:
            per_gen[gid] = sum(score_map.get((gid, hour), 0.0) for hour in window)

        selected = [
            gid
            for gid, _ in sorted(
                per_gen.items(),
                key=lambda item: (item[1], item[0]),
                reverse=True,
            )[:generator_count]
        ]
        total = sum(score_map.get((gid, hour), 0.0) for gid in selected for hour in window)
        if best is None or total > best[2]:
            best = (window, selected, total)

    if best is None:
        raise RuntimeError("Could not select a structured active block.")

    selected_hours, selected_generators, block_score = best
    positions = [(gid, hour) for gid in selected_generators for hour in selected_hours]
    if len(positions) > qubit_budget:
        raise RuntimeError(
            f"Selected block uses {len(positions)} variables, exceeding budget {qubit_budget}."
        )

    selected_positions = set(positions)
    for score in scores:
        score.selected = (score.generator_id, score.hour) in selected_positions

    return CandidateBlock(
        generator_ids=selected_generators,
        hours=selected_hours,
        positions=positions,
        rationale=(
            f"Structured {len(selected_generators)}×{len(selected_hours)} active block "
            f"covering hours {selected_hours[0]}–{selected_hours[-1]} and using "
            f"{len(positions)}/{qubit_budget} available qubits."
        ),
        block_score=round(block_score, 8),
    )
