from __future__ import annotations

from collections import defaultdict

from app.models.schemas import CandidateBlock, DatasetModel, DispatchResult, QUBOProblem


def _add_linear(linear: dict[str, float], i: int, value: float) -> None:
    key = str(i); linear[key] = linear.get(key, 0.0) + float(value)


def _add_quadratic(quadratic: dict[str, float], i: int, j: int, value: float) -> None:
    if i == j:
        raise ValueError("Diagonal QUBO coefficients belong in the linear dictionary.")
    a, b = sorted((i, j)); key = f"{a},{b}"
    quadratic[key] = quadratic.get(key, 0.0) + float(value)


def build_dynamic_qubo(
    dataset: DatasetModel,
    incumbent: dict[tuple[str, int], int],
    block: CandidateBlock,
    dispatch: DispatchResult,
    residual: list[float],
    dual: list[float],
    rho: float,
    *,
    deviation_weight: float = 0.15,
    temporal_weight: float = 0.08,
) -> QUBOProblem:
    """Build the ADMM-guided active-block QUBO for one outer round.

    Active variables are absolute commitment values q_i, not flip flags.
    The predicted residual is linearized around the incumbent:
        r_t(q) = r_t - sum_i A_ti (q_i - u_i).
    """
    variable_order = list(block.positions)
    n = len(variable_order)
    if n <= 0:
        raise ValueError("Active block must contain at least one variable.")
    index = {position: i for i, position in enumerate(variable_order)}
    gen_map = {g.id: g for g in dataset.generators}
    hour_index = {hour: t for t, hour in enumerate(dataset.hours)}
    dispatch_by_hour = {int(row["hour"]): row for row in dispatch.hourly_dispatch}

    offset = 0.0
    linear: dict[str, float] = {str(i): 0.0 for i in range(n)}
    quadratic: dict[str, float] = {}

    # Economic surrogate: no-load plus estimated variable production cost.
    effective_capacity: dict[tuple[int, int], float] = {}
    per_hour_active: dict[int, list[int]] = defaultdict(list)
    for i, (gid, hour) in enumerate(variable_order):
        gen = gen_map[gid]
        t = hour_index[hour]
        row = dispatch_by_hour.get(hour, {})
        outputs = row.get("generator_output_mw", {}) or {}
        actual = float(outputs.get(gid, 0.0))
        hour_residual = max(0.0, float(residual[t])) if t < len(residual) else 0.0
        incumbent_value = int(incumbent[(gid, hour)])
        if incumbent_value:
            a = max(float(gen.p_min), actual)
        else:
            active_count = max(1, sum(1 for pos in variable_order if pos[1] == hour))
            a = min(float(gen.p_max), max(float(gen.p_min), hour_residual / active_count + float(gen.p_min)))
        effective_capacity[(t, i)] = a
        per_hour_active[t].append(i)

        expected_output = max(float(gen.p_min), min(float(gen.p_max), a))
        economic = float(gen.no_load_cost) + 0.35 * float(gen.variable_cost) * expected_output
        _add_linear(linear, i, economic)

        # Mild trust-region penalty (q_i - u_i)^2.
        if incumbent_value == 0:
            _add_linear(linear, i, deviation_weight)
        else:
            offset += deviation_weight
            _add_linear(linear, i, -deviation_weight)

    # Exact startup/shutdown terms inside the window and boundary constants.
    for gid in block.generator_ids:
        gen = gen_map[gid]
        active_hours = sorted(hour for g, hour in variable_order if g == gid)
        active_set = set(active_hours)
        for hour in active_hours:
            i = index[(gid, hour)]
            previous_hour = hour - 1
            if previous_hour in active_set:
                j = index[(gid, previous_hour)]
                # SU q_t(1-q_prev) + SD(1-q_t)q_prev
                _add_linear(linear, i, gen.startup_cost)
                _add_linear(linear, j, gen.shutdown_cost)
                _add_quadratic(quadratic, i, j, -(gen.startup_cost + gen.shutdown_cost))
            else:
                previous = gen.initial_status if hour == dataset.hours[0] else incumbent[(gid, previous_hour)]
                offset += gen.shutdown_cost * previous
                _add_linear(
                    linear, i,
                    gen.startup_cost * (1 - previous) - gen.shutdown_cost * previous,
                )

        # Right boundary: changing the final active variable may create a
        # startup/shutdown transition into the fixed next-hour state.
        last_hour = active_hours[-1]
        if last_hour < dataset.hours[-1]:
            i = index[(gid, last_hour)]
            next_value = incumbent[(gid, last_hour + 1)]
            # SU_next * next(1-q_last) + SD_next*(1-next)q_last
            offset += gen.startup_cost * next_value
            _add_linear(
                linear, i,
                -gen.startup_cost * next_value + gen.shutdown_cost * (1 - next_value),
            )

        # Temporal smoothness eta(q_t-q_{t-1})^2 for active-active pairs.
        for left, right in zip(active_hours, active_hours[1:]):
            if right != left + 1: continue
            i, j = index[(gid, left)], index[(gid, right)]
            _add_linear(linear, i, temporal_weight)
            _add_linear(linear, j, temporal_weight)
            _add_quadratic(quadratic, i, j, -2.0 * temporal_weight)

    # ADMM augmented-Lagrangian term for each hour.
    predicted_constants: dict[int, float] = {}
    for t, hour in enumerate(dataset.hours):
        active_indices = per_hour_active.get(t, [])
        if not active_indices:
            continue
        b = float(residual[t])
        for i in active_indices:
            gid, active_hour = variable_order[i]
            b += effective_capacity[(t, i)] * incumbent[(gid, active_hour)]
        predicted_constants[t] = b
        lam = float(dual[t]) if t < len(dual) else 0.0
        offset += lam * b + 0.5 * rho * b * b
        for i in active_indices:
            a_i = effective_capacity[(t, i)]
            _add_linear(linear, i, -lam * a_i - rho * b * a_i + 0.5 * rho * a_i * a_i)
        for pos, i in enumerate(active_indices):
            for j in active_indices[pos + 1:]:
                _add_quadratic(quadratic, i, j, rho * effective_capacity[(t, i)] * effective_capacity[(t, j)])

    # Scale all non-constant coefficients to a numerically stable range for QAOA.
    coefficient_scale = max(
        [abs(value) for value in linear.values()] +
        [abs(value) for value in quadratic.values()] + [1e-9]
    )
    normalized_linear = {key: value / coefficient_scale for key, value in linear.items()}
    normalized_quadratic = {key: value / coefficient_scale for key, value in quadratic.items() if abs(value) > 1e-12}
    normalized_offset = offset / coefficient_scale

    return QUBOProblem(
        dimension=n,
        offset=normalized_offset,
        linear=normalized_linear,
        quadratic=normalized_quadratic,
        variable_order=variable_order,
        penalty_weights={
            "rho": rho,
            "deviation": deviation_weight,
            "temporal": temporal_weight,
        },
        metadata={
            "formulation": "admm_guided_dynamic_active_block",
            "residual_convention": "shortage_minus_surplus",
            "coefficient_scale": coefficient_scale,
            "raw_offset": offset,
            "raw_linear": linear,
            "raw_quadratic": quadratic,
            "dual": list(dual),
            "residual": list(residual),
            "predicted_residual_constants": predicted_constants,
            "effective_capacity": {
                f"{t},{i}": value for (t, i), value in effective_capacity.items()
            },
            "incumbent_bitstring": "".join(str(incumbent[position]) for position in variable_order),
        },
    )


def build_qubo(*args, **kwargs) -> QUBOProblem:
    """Compatibility alias for the new dynamic builder."""
    return build_dynamic_qubo(*args, **kwargs)


def evaluate_qubo_energy(problem: QUBOProblem, bitstring: str) -> float:
    if len(bitstring) != problem.dimension:
        raise ValueError("Bitstring length does not match QUBO dimension.")
    bits = [1 if bit == "1" else 0 for bit in bitstring]
    energy = float(problem.offset)
    for key, value in problem.linear.items(): energy += float(value) * bits[int(key)]
    for key, value in problem.quadratic.items():
        i, j = (int(part) for part in key.split(","))
        energy += float(value) * bits[i] * bits[j]
    return float(energy)
