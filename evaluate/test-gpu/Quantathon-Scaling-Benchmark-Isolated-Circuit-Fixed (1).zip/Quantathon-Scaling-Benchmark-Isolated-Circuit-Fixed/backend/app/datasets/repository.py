from __future__ import annotations

from app.datasets.default_dataset import load_default_dataset
from app.models.schemas import DatasetModel


class DatasetRepository:
    def __init__(self) -> None:
        dataset = load_default_dataset()
        self._datasets = {dataset.id: dataset}

    def list_datasets(self):
        return list(self._datasets.values())

    def get_dataset(self, dataset_id: str):
        return self._datasets[dataset_id]

    def register_dataset(self, dataset: DatasetModel, *, overwrite: bool = False) -> None:
        """Register an in-memory dataset for isolated benchmark runs.

        The frontend demo still sees only the default dataset unless benchmark
        code explicitly registers a generated dataset on its own service instance.
        """
        if dataset.id in self._datasets and not overwrite:
            raise ValueError(f"Dataset '{dataset.id}' is already registered.")
        self._datasets[dataset.id] = dataset
