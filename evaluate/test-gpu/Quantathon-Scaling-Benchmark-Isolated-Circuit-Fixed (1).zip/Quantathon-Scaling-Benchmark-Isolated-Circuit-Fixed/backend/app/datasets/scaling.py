from __future__ import annotations

import random

from app.models.schemas import DatasetModel, GeneratorSpec


def _scaled(values: list[float], factor: float) -> list[float]:
    return [round(max(0.0, float(value) * factor), 6) for value in values]


def generate_scaled_dataset(
    base: DatasetModel,
    total_generators: int,
    *,
    seed: int = 7,
    dataset_id: str | None = None,
) -> DatasetModel:
    """Create a deterministic synthetic UC dataset from the demo dataset.

    Generator templates are cycled with small deterministic perturbations.
    Demand, renewable availability and reserve are scaled by the *actual* total
    Pmax ratio, preserving the original relative system stress more closely than
    scaling only by the generator count.
    """
    if total_generators < 1:
        raise ValueError("total_generators must be at least 1.")
    if not base.generators:
        raise ValueError("Base dataset contains no generators.")

    rng = random.Random(seed)
    templates = base.generators
    generated: list[GeneratorSpec] = []

    for index in range(total_generators):
        template = templates[index % len(templates)]
        generation = index // len(templates)

        # Keep the first copy exactly equal to the demo. Additional copies get
        # small, repeatable perturbations so the larger system is not made of
        # perfectly identical units.
        if generation == 0:
            capacity_factor = 1.0
            cost_factor = 1.0
            ramp_factor = 1.0
        else:
            capacity_factor = 1.0 + rng.uniform(-0.06, 0.06)
            cost_factor = 1.0 + 0.015 * generation + rng.uniform(-0.025, 0.025)
            ramp_factor = 1.0 + rng.uniform(-0.08, 0.08)

        p_max = max(1.0, float(template.p_max) * capacity_factor)
        p_min = min(p_max, max(0.0, float(template.p_min) * capacity_factor))
        initial_output = 0.0
        if template.initial_status:
            initial_output = min(p_max, max(p_min, float(template.initial_output) * capacity_factor))

        generated.append(
            GeneratorSpec(
                id=f"G{index + 1}",
                name=(
                    template.name
                    if generation == 0
                    else f"{template.name}-Scale{generation + 1}"
                ),
                p_min=round(p_min, 6),
                p_max=round(p_max, 6),
                variable_cost=round(float(template.variable_cost) * cost_factor, 6),
                no_load_cost=round(float(template.no_load_cost) * cost_factor, 6),
                startup_cost=round(float(template.startup_cost) * cost_factor, 6),
                shutdown_cost=round(float(template.shutdown_cost) * cost_factor, 6),
                ramp_up=round(max(0.0, float(template.ramp_up) * ramp_factor), 6),
                ramp_down=round(max(0.0, float(template.ramp_down) * ramp_factor), 6),
                min_up_time=template.min_up_time,
                min_down_time=template.min_down_time,
                initial_status=template.initial_status,
                initial_output=round(initial_output, 6),
            )
        )

    base_capacity = sum(float(gen.p_max) for gen in base.generators)
    new_capacity = sum(float(gen.p_max) for gen in generated)
    capacity_scale = new_capacity / max(base_capacity, 1e-12)

    renewable = _scaled(base.renewable, capacity_scale)
    if base.solar_available and len(base.solar_available) == len(base.hours):
        solar = _scaled(base.solar_available, capacity_scale)
    else:
        solar = [round(0.65 * value, 6) for value in renewable]
    if base.wind_available and len(base.wind_available) == len(base.hours):
        wind = _scaled(base.wind_available, capacity_scale)
    else:
        wind = [round(value - solar_value, 6) for value, solar_value in zip(renewable, solar)]

    return base.model_copy(
        deep=True,
        update={
            "id": dataset_id or f"scaled_{total_generators}g_24h_seed{seed}",
            "name": f"Scaled {total_generators}-Generator 24-Hour System",
            "description": (
                "Synthetic scaling dataset generated only for CUDA-Q qubit/system "
                "benchmarking; the frontend demo dataset is unchanged."
            ),
            "demand": _scaled(base.demand, capacity_scale),
            "renewable": renewable,
            "reserve": _scaled(base.reserve, capacity_scale),
            "solar_available": solar,
            "wind_available": wind,
            "grid_import_limit_mw": round(float(base.grid_import_limit_mw) * capacity_scale, 6),
            "initial_battery_soc_mwh": round(float(base.initial_battery_soc_mwh) * capacity_scale, 6),
            "battery_capacity_mwh": round(float(base.battery_capacity_mwh) * capacity_scale, 6),
            "battery_charge_limit_mw": round(float(base.battery_charge_limit_mw) * capacity_scale, 6),
            "battery_discharge_limit_mw": round(float(base.battery_discharge_limit_mw) * capacity_scale, 6),
            "generators": generated,
        },
    )


def dataset_scaling_metadata(base: DatasetModel, scaled: DatasetModel) -> dict[str, float | int | str]:
    base_capacity = sum(float(gen.p_max) for gen in base.generators)
    scaled_capacity = sum(float(gen.p_max) for gen in scaled.generators)
    return {
        "dataset_id": scaled.id,
        "total_generators": len(scaled.generators),
        "total_commitment_variables": len(scaled.generators) * len(scaled.hours),
        "base_capacity_mw": round(base_capacity, 6),
        "total_capacity_mw": round(scaled_capacity, 6),
        "capacity_scale": round(scaled_capacity / max(base_capacity, 1e-12), 8),
        "peak_demand_mw": round(max(scaled.demand, default=0.0), 6),
        "peak_renewable_mw": round(max(scaled.renewable, default=0.0), 6),
        "peak_reserve_mw": round(max(scaled.reserve, default=0.0), 6),
    }
