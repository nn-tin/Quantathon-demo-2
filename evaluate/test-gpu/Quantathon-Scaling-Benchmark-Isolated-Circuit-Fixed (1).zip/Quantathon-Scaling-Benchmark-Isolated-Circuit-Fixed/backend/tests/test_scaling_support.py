from __future__ import annotations

import pytest

from app.baseline.heuristic import build_baseline_schedule
from app.candidate_selection.block import select_candidate_block
from app.candidate_selection.scoring import score_candidates
from app.datasets.default_dataset import load_default_dataset
from app.datasets.repository import DatasetRepository
from app.datasets.scaling import dataset_scaling_metadata, generate_scaled_dataset
from app.dispatch.economic_dispatch import solve_relaxed_economic_dispatch
from app.models.schemas import HybridConfig
from app.preprocessing.preprocess import compute_relaxed_commitment
from app.qubo.builder import build_dynamic_qubo


def test_scaled_dataset_preserves_relative_capacity_stress():
    base = load_default_dataset()
    scaled = generate_scaled_dataset(base, 15, seed=17)
    metadata = dataset_scaling_metadata(base, scaled)

    assert len(scaled.generators) == 15
    assert len(scaled.demand) == 24
    assert len(scaled.renewable) == 24
    assert len(scaled.reserve) == 24
    assert metadata["capacity_scale"] > 1.0

    base_capacity = sum(gen.p_max for gen in base.generators)
    scaled_capacity = sum(gen.p_max for gen in scaled.generators)
    assert max(scaled.demand) / max(base.demand) == pytest.approx(
        scaled_capacity / base_capacity,
        rel=1e-6,
    )


def test_repository_registration_is_local_to_service_instance():
    base = load_default_dataset()
    scaled = generate_scaled_dataset(base, 12, seed=5)
    repository = DatasetRepository()
    repository.register_dataset(scaled)
    assert repository.get_dataset(scaled.id).id == scaled.id
    assert DatasetRepository().list_datasets()[0].id == "default_10x24"


def test_dynamic_block_and_qubo_support_12_qubits():
    dataset = generate_scaled_dataset(load_default_dataset(), 12, seed=12)
    fractional = compute_relaxed_commitment(dataset)
    incumbent = build_baseline_schedule(dataset, fractional)
    dispatch = solve_relaxed_economic_dispatch(dataset, incumbent)
    dual = [0.0] * len(dataset.hours)
    scores = score_candidates(
        dataset,
        fractional,
        incumbent,
        dispatch,
        dual,
        HybridConfig().score_weights,
    )
    block = select_candidate_block(
        dataset,
        scores,
        candidate_generators=3,
        candidate_hours=4,
        qubit_budget=12,
    )
    qubo = build_dynamic_qubo(
        dataset,
        incumbent,
        block,
        dispatch,
        dispatch.residual,
        dual,
        rho=0.08,
    )

    assert len(block.generator_ids) == 3
    assert len(block.hours) == 4
    assert len(block.positions) == 12
    assert qubo.dimension == 12
