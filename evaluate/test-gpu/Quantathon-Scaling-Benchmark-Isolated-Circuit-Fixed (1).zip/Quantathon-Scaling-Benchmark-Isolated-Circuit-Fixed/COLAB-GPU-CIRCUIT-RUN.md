# Colab T4 GPU + API + QAOA Circuit

Use `Run_Quantathon_Full_GPU_API_Circuits_Colab.ipynb`.

The backend is configured with:

- `CUDAQ_TARGET=nvidia`
- `REQUIRE_CUDAQ=1`
- `PRINT_QAOA_CIRCUIT=1`
- `QAOA_CIRCUIT_DIR=/content/qaoa-circuits`

Each executed ADMM round writes:

- `admm_round_XX_Nq_circuit.txt`
- `admm_round_XX_Nq_cudaq_kernel.py`
- `admm_round_XX_Nq_metadata.json`

The notebook triggers one 10-qubit run locally, displays every circuit produced,
then starts a Cloudflare Quick Tunnel for the frontend.

Circuit drawing is presentation/debug overhead. Disable it for official runtime
benchmarking by setting `PRINT_QAOA_CIRCUIT=0`.
