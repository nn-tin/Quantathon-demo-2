# Scaling benchmark without changing the frontend demo

## What changed from the original project

Only the backend's accepted active-block dimensions were generalized, and an isolated benchmark tool was added.

Core changes:

- `backend/app/models/schemas.py`: wider validation ranges; defaults remain 10 qubits, 2 generators, 5 hours, Top-K 10.
- `backend/app/candidate_selection/block.py`: block shape now uses the supplied benchmark configuration instead of hard-coding 2×4/5.
- `backend/app/qubo/builder.py`: accepts any positive active-block dimension.
- `backend/app/datasets/repository.py`: adds in-memory dataset registration for a benchmark service instance.
- `backend/app/datasets/scaling.py`: generates deterministic larger datasets and scales demand/renewable/reserve by actual total capacity.
- `evaluate/qubit-scaling/*`: independent CSV-driven benchmark runner and output files.
- `run_qubit_scaling_colab.ipynb`: T4 launcher.

Unchanged:

- the complete `frontend/` directory;
- `sample-run-request.json`;
- `backend/app/datasets/default_dataset.py`;
- default API behavior and default HybridConfig values.

## Why the CSV is isolated

The original Tin version used a CSV mapping inside `PipelineService`, which could silently override a frontend request. This version does not import any benchmark CSV in the API pipeline.

`benchmark_plan.csv` is read only by:

```text
evaluate/qubit-scaling/run_scaling.py
```

The benchmark creates a private `PipelineService`, registers a generated dataset in that service instance, and writes results. The running demo backend never sees those datasets or settings.

## Colab sequence

1. Enable T4.
2. Upload this project ZIP.
3. Open and run `run_qubit_scaling_colab.ipynb`, or use:

```bash
python -m pip install -r backend/requirements-quantum-colab.txt

CUDAQ_TARGET=nvidia REQUIRE_CUDAQ=1 PYTHONPATH=backend \
python evaluate/qubit-scaling/run_scaling.py \
  --target nvidia --require-cudaq --max-qubits 24
```

4. Run 28 and 30 qubits separately:

```bash
CUDAQ_TARGET=nvidia REQUIRE_CUDAQ=1 PYTHONPATH=backend \
python evaluate/qubit-scaling/run_scaling.py \
  --target nvidia --require-cudaq --case q28_joint

CUDAQ_TARGET=nvidia REQUIRE_CUDAQ=1 PYTHONPATH=backend \
python evaluate/qubit-scaling/run_scaling.py \
  --target nvidia --require-cudaq --case q30_joint
```

5. Download `evaluate/qubit-scaling/results/`.

## CSV outputs

- `scaling_raw.csv`: every run, seed, dataset scale, source, target, objective mode, cost, feasibility and runtime.
- `scaling_summary.csv`: averages by qubit case.
- `datasets/*.json`: exact generated UC dataset for reproducibility.

The runner saves after every case, so completed results remain available if a larger T4 case fails.
